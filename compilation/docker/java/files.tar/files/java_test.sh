#!/bin/bash
source /root/.bashrc
javac -classpath ${CLASSPATH} Main.java Kata.java
java Main


